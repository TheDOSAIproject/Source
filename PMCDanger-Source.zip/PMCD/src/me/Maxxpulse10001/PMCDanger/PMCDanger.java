package me.Maxxpulse10001.PMCDanger;

import java.util.List;

import org.bukkit.Bukkit;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;


public class PMCDanger extends JavaPlugin implements Listener {
 
        @EventHandler
        public void onPlayerChat(AsyncPlayerChatEvent e) {

                for (String word : e.getMessage().split(" ")){
                	
                        if (getConfig().getStringList("pmcblockers").contains(word)) {
                                e.setCancelled(true);
                                List<String> messages = getConfig().getStringList("message");
                                for(String m : messages) {
                                	e.getPlayer().sendMessage(ChatColor.RED + "" + ChatColor.BOLD + "Hey! " + ChatColor.WHITE + m);
                                }      
                             
                        }
                }
        }
        @Override
        public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        	if (sender instanceof Player) {
        		
                   Player player = (Player) sender;
                   if (cmd.getName().equalsIgnoreCase("loadtrolls")) {
                	   if (player.hasPermission("PMCDanger.loadtrolls")) {
                		   sender.sendMessage(ChatColor.GREEN + "Checking Wordlist...");
                		    getLogger().info("Loading Wordlist!");
                            getConfig().options().copyDefaults(true);
                            saveConfig();
                            Bukkit.getServer().getPluginManager().registerEvents(this, this);
                            sender.sendMessage(ChatColor.GREEN + "Done!");
                		} else {
                			 sender.sendMessage("Im sorry! Your Not allowed to Access that!");
                		}
               		return true;
               	    }
                } else {
                   sender.sendMessage("You are a bot!");
                   return false;
                }
                // do something
                return false;
        }
        public void onEnable() {
        	    getLogger().info("Server is now Protected!");
                getConfig().options().copyDefaults(true);
                saveConfig();
                Bukkit.getServer().getPluginManager().registerEvents(this, this);
        }
     
}